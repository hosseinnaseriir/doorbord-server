export enum RoleEnum {
    USER = 'user',
    ADMIN = 'admin',
    SUPER_ADMIN = 'super_admin',
    SUPERVISOR = 'supervisor',
    TECHNICIAN = 'technician',
    SALES = 'sales',
}
